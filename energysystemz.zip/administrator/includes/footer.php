<tr>
	<td class="headertop" style="color:#FFF;">
 &copy; <?php echo date("Y");?> Energysystem.com. All Rights Reserved
	</tr>
	
	</table>
</div>
</body>
</html>