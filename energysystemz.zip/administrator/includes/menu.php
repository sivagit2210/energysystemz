<ul class="sexypanels">
<li><a href="home.php"> >>  Home</a></li>
<li><a href="manage_page_content.php"> >>  Page Contents</a></li>
<li><a href="projects.php"> >>  Manage Products</a></li>
<li><a href="manage_page.php"> >>  Manage Service</a></li>
<li><a href="slide_show.php"> >>  Manage Projects</a></li>

<li><a href="news.php"> >>  News & Events</a></li>
<li><a href="appointments.php"> >>  Product Enquiry</a></li>
<li><a href="testimonial.php"> >>  Testimonials</a></li>

<!--
<li><a href="news.php"> >>  Latest News</a></li>
<li><a href="advertisment.php"> >>  Adevertisment</a></li>
<li><a href="videos.php"> >>  Videos</a></li>
<li><a href="publications.php"> >>  Publications</a></li>
<li><a href="setting.php"> >>  Settings</a></li>-->
</ul>