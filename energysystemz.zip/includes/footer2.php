<div style="background:url(images/bottom-pan1.jpg) top left no-repeat; height:254px; padding:37px 110px 0 45px;">
    	<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td width="187" valign="top" class="bottom-panediv"><h1>About Us</h1>
    <p><a href="#">Company Profile</a><br />
      <a href="#">Our History</a><br />
      <a href="#">Vision & Mission</a><br />
      <a href="#">Our Team</a></p>
    </td>
    <td width="209" valign="top" class="bottom-panediv"><h1>Our Client</h1>
    <p><a href="#">Working Together</a><br />
      <a href="#">Example Clients</a><br />
      <a href="#">Case Study Timeline</a><br />
      <a href="#">Client Testimonials</a></p>
    </td>
    <td width="183" valign="top" class="bottom-panediv"><h1>Our Services</h1>
    <p><a href="#">Consulting</a><br />
      <a href="#">Development</a><br />
      <a href="#">On-Demand</a><br />
      <a href="#">Training</a></p>
    </td>
    <td valign="top" class="bottom-panediv1"><p><i>Sed ut perspiciatis unde omnis iste natus, error sit voluptatem accusantium <a href="#" style="color:#fff;"><i>http://bit.ly/bkPfFM</i></a> doloremque laudantium, totam rem aperiamea.</i> <strong>3 hours ago<br />
      <br />
@jacquelinecharl</strong></p>
    </td>  </tr>
</table>

    </div>
    
    <div class="clearfix footer">
    	<div class="footer-td1">Copyright � 2010 Univarr.com. All Rights Reserved</div>
        <div class="footer-td2"><a href="#">Change Language</a> |  <a href="#">Terms and Conditions</a> |  <a href="#">Accessibility</a></div>
    </div>
    </div>
</div>    

</body>
</html>