<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Index</title>
<link rel="stylesheet" type="text/css" href="css/style.css" />
</head>
<body>
<div class="maintop-bgimg">
	<div class="maindiv">
    	<!-- hd div -->
        <div class="hdmain1">
        	<div class="hdmain-logo"><img src="images/logo.gif" width="191" height="72" /></div>
          <div class="hdmain-nav"> <h1>
          <a href="#">Home</a> |  <a href="#">Clients</a> |  <a href="#">careers</a> |  <a href="#">contact us</a> |  <a href="#">sitemap</a></h1>
          <div id="foxmenucontainer">		
	<div id="foxmenu">
	<ul>
	<li><a href="#" title="">Corporate profile</a></li>
	<li><a href="#" title="">services</a></li>
	<li><a href="#" title="" class="current">outsourcing</a></li>
	<li><a href="#" title="">our benefits</a></li>
	<li><a href="#" title="">partners</a></li>
	</ul>
	</div>
	</div>
          </div>
        </div>
   	  <!-- hd div  // -->
    <div class="indexbanner"><img src="images/banner-img1.jpg" width="960" height="331" /></div>