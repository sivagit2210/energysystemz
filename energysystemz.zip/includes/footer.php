<div class="pagefooter_main" >
<div class="pagefooter" >
<ul>
 
 <li><a href="index.php">Home</a></li>
 
  <li><a href="aboutus.php">Aboutus</a></li>
  
 <li><a href="products.php">Products</a></li>
 
  <li><a href="services.php">Services</a></li>

    <li><a href="media.php">News & Events</a></li>
  
   <li><a href="#">Clients</a></li>
  
     <li><a href="#">Certificates</a></li>
  
   <li><a href="contactus.php">Contactus</a></li>
  
</ul>	
</div>
</div>
<div class="footnote" align="center">
	Copyright 2012 Energy Systems Pvt.ltd. All Rights Reserved
	</div>
</body>
</html>